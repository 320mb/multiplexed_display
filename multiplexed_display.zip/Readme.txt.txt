this is the Raw Binary/Hex Dump file for the Multiplexed Display for the Ben Eater 8 bit Breadboard computer.  

https://eater.net/8bit